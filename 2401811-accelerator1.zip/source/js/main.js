import './video';
import './price';
import './juri';
import './faq';
import './reviews';
import './accordeon';
import './form';
